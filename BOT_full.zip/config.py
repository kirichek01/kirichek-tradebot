class CONFIG:
    telegram_channels = []
    telegram_bot_token = ""
    telegram_target_chat = ""
    openai_api_key = ""
    session_path = ""
    theme = "Dark"
    db_path = "data/signals.db"