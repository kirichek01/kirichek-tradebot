Combine Trade Bot by Kirichek
-----------------------------

1. Установи зависимости:
   pip install -r requirements.txt

2. Запусти:
   python main.py