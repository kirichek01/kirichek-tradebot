import json
import csv
from core.database import get_all_signals

def export_signals_to_json(path):
    signals = get_all_signals()
    with open(path, "w", encoding="utf-8") as f:
        json.dump([{
            "timestamp": str(s.timestamp),
            "channel": s.channel,
            "parsed": s.parsed
        } for s in signals], f, indent=2)

def export_signals_to_csv(path):
    signals = get_all_signals()
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["timestamp", "channel", "action", "symbol", "sl", "tp"])
        for s in signals:
            parsed = eval(s.parsed) if s.parsed else {}
            writer.writerow([
                str(s.timestamp),
                s.channel,
                parsed.get("action", ""),
                parsed.get("symbol", ""),
                parsed.get("sl", ""),
                parsed.get("tp", "")
            ])