import openai
import json
from config import CONFIG

PROMPT_STORE = "data/channel_prompts.json"

def fetch_messages_from_channel(channel_id, limit=15):
    # Здесь будет интеграция с Telegram
    return [
        "BUY XAUUSD NOW! SL: 2310, TP: 2330",
        "Gold long at 2320, targets 2345",
        "Close 50% of position at 2330, SL BE"
    ]

def analyze_channel_style(channel_id):
    messages = fetch_messages_from_channel(channel_id)
    combined_text = "\n".join(messages)
    prompt_request = f"Analyze the following messages and generate a parsing strategy to extract trading signals:\n{combined_text}\n---\nReturn in JSON or bullet format"

    openai.api_key = CONFIG.openai_api_key
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt_request}],
            temperature=0.5
        )
        result = response.choices[0].message.content
        store_prompt(channel_id, result)
        return result
    except Exception as e:
        return str(e)

def store_prompt(channel_id, prompt):
    try:
        with open(PROMPT_STORE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except:
        data = {}
    data[channel_id] = prompt
    with open(PROMPT_STORE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def get_prompt(channel_id):
    try:
        with open(PROMPT_STORE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get(channel_id, "")
    except:
        return ""