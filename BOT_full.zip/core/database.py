from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text
from sqlalchemy.orm import sessionmaker, declarative_base
import datetime
from config import CONFIG

Base = declarative_base()
engine = create_engine(f"sqlite:///{CONFIG.db_path}", echo=False)
Session = sessionmaker(bind=engine)

class Signal(Base):
    __tablename__ = 'signals'
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    channel = Column(String)
    raw_message = Column(Text)
    parsed = Column(Text)

def init_db():
    Base.metadata.create_all(engine)

def save_signal(channel, raw_message, parsed_json):
    session = Session()
    signal = Signal(channel=channel, raw_message=raw_message, parsed=parsed_json)
    session.add(signal)
    session.commit()
    session.close()

def get_all_signals():
    session = Session()
    result = session.query(Signal).order_by(Signal.timestamp.desc()).all()
    session.close()
    return result