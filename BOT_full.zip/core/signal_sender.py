import requests
from config import CONFIG

def send_signal_to_bot(signal_text):
    token = CONFIG.telegram_bot_token
    chat_id = CONFIG.telegram_target_chat
    if not token or not chat_id:
        print("Bot token or chat ID not set.")
        return

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {"chat_id": chat_id, "text": signal_text}

    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
    except Exception as e:
        print(f"Error sending to Telegram bot: {e}")