import json
from config import CONFIG

def export_config(filepath):
    data = {
        "openai_api_key": CONFIG.openai_api_key,
        "theme": CONFIG.theme,
        "telegram_channels": CONFIG.telegram_channels,
        "telegram_bot_token": CONFIG.telegram_bot_token,
        "telegram_target_chat": CONFIG.telegram_target_chat,
        "session_path": CONFIG.session_path
    }
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def import_config(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    CONFIG.openai_api_key = data.get("openai_api_key", "")
    CONFIG.theme = data.get("theme", "dark")
    CONFIG.telegram_channels = data.get("telegram_channels", [])
    CONFIG.telegram_bot_token = data.get("telegram_bot_token", "")
    CONFIG.telegram_target_chat = data.get("telegram_target_chat", "")
    CONFIG.session_path = data.get("session_path", "")