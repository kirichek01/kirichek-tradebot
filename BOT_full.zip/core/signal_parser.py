import openai
import json
from config import CONFIG

openai.api_key = CONFIG.openai_api_key

async def parse_message_with_gpt(message_text: str) -> dict | None:
    try:
        response = await openai.ChatCompletion.acreate(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Извлеки торговый сигнал из текста. Верни JSON с полями: action (BUY/SELL), symbol, sl, tp, volume"},
                {"role": "user", "content": message_text}
            ]
        )
        content = response.choices[0].message["content"]
        return json.loads(content)
    except Exception as e:
        print("GPT parsing error:", e)
        return None