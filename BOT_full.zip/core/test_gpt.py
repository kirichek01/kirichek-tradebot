from openai import OpenAI
from config import CONFIG

def parse_text_with_gpt(text):
    import openai
    openai.api_key = CONFIG.openai_api_key

    prompt = f"Extract trading signal from this message: {text}"

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3
        )
        content = response.choices[0].message.content
        return content
    except Exception as e:
        return str(e)