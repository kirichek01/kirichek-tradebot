import json
from pathlib import Path
from config import CONFIG

def save_tc_file(signal_dict: dict):
    if not CONFIG.traderconnector_path:
        print("TraderConnector path not set")
        return

    payload = {
        "type": "signal",
        "data": {
            "symbol": signal_dict.get("symbol"),
            "action": signal_dict.get("action"),
            "sl": signal_dict.get("sl"),
            "tp": signal_dict.get("tp"),
            "volume": signal_dict.get("volume")
        }
    }

    try:
        Path(CONFIG.traderconnector_path).write_text(json.dumps(payload, indent=2))
        print("✅ .tc file saved.")
    except Exception as e:
        print("Error saving .tc file:", e)