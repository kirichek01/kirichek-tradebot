from telethon import TelegramClient, events
from config import CONFIG
import asyncio

class TelegramUserbot:
    def __init__(self, on_message_callback):
        self.client = None
        self.on_message_callback = on_message_callback

    async def connect(self, api_id, api_hash):
        self.client = TelegramClient(str(CONFIG.session_file), api_id, api_hash)
        await self.client.start()
        print("✅ Telegram connected")

        @self.client.on(events.NewMessage(chats=CONFIG.channels))
        async def handler(event):
            message = event.message.message
            await self.on_message_callback(message)

    def run(self):
        self.client.run_until_disconnected()